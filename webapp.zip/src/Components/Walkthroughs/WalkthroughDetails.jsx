import Toolbar from "../../Components/Common/Toolbar";

export default function WalkthroughDetails({ switchView }) {
    return (<div>
    <Toolbar switchView={switchView}/>
    <p>Walkthrough Details</p>
    </div>)
}