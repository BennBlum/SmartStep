import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

//Works
// const body = document.querySelector("body");
// const div = document.createElement("div");
// div.style.position = "fixed";
// div.style.bottom = "0";
// div.style.right = "0";
// div.style.width = "60px";
// div.style.height = "60px";
// div.style.backgroundColor = "red";
// div.style.color = "white";
// div.style.padding = "10px";
// div.innerText = "Bottom Right Corner";
// if (body) {
//   body.appendChild(div);
// }

// // extension
// const body = document.querySelector("body");
// const app = document.createElement("div");
// app.style.position = "fixed";
// // app.style.bottom = "20px";
// // app.style.right = "20px";
// app.style.width = "300px";
// app.style.height = "455px";
// app.style.zIndex = "9999";


// app.id = "root"
// if (body) {
//   body.appendChild(app);
// }
// const root = ReactDOM.createRoot(app);


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

reportWebVitals();