import React from 'react';
import '../index.css';
import { toggleChatbot, ViewNames } from '../Common';

export function Welcome({ switchMainView }) {
    return (
        <div id="divWelcome">
            <div id="applogo" className="chatbot-header">
                <img src="smartstep.png" className="app-logo" alt="Logo" />
                <button id="btnClose" className="close-btn" onClick={toggleChatbot}>×</button>
            </div>
            <p className="sub-body">Welcome to SmartStep, a guidance system that is designed to assist you with any task you need help
                with. Whether you're new to our
                platform or a seasoned pro, our features are designed to make your experience seamless and
                enjoyable. Let's dive in and achieve great things together!</p>
            <button id="btnWelcome" className="std-btn" onClick={() => switchMainView(ViewNames.SEARCH)}>Let's go!</button>
        </div>
    );
}
